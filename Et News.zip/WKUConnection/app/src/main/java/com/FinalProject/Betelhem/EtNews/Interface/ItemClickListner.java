package com.FinalProject.Betelhem.EtNews.Interface;

import android.view.View;

/**
 * Created by voodoo on 11/10/2017.
 */

public interface ItemClickListner {

    void onClick(View view, int position, boolean isLongClick);
}
